# Panduan Lengkap Instalasi & Pemakaian (Member)
## EA PICA NEURAL GOLD M1 — AI Deep Scalper MT5

Dokumen ini adalah panduan resmi instalasi bagi member untuk menjalankan Expert Advisor (EA) berbasis model AI Deep Residual Network pada MetaTrader 5.

---

## 1. Struktur File Paket

Paket ini sudah disusun sesuai hierarki folder resmi MetaTrader 5 (`MQL5`):

```text
PICA_Neural_Gold_M1_Package_Member/
├── MQL5/
│   ├── Experts/
│   │   └── PICA_Neural_Gold_M1_MT5.ex5        <-- File Program EA Utama
│   ├── Files/
│   │   └── PICA_Neural_Gold_M1.onnx          <-- File Model Artificial Intelligence
│   └── Presets/
│       ├── 01_PICA_M1_Aggressive_HighFrequency.set
│       ├── 02_PICA_M1_Balanced_Recommended.set
│       ├── 03_PICA_M1_Conservative.set
│       └── 04_PICA_M1_Sniper.set
├── PANDUAN_INSTALASI_MEMBER.txt
└── PANDUAN_INSTALASI_MEMBER.md
```

---

## 2. Cara Pemasangan di MetaTrader 5

### Metode 1: Cara Cepat (Sangat Direkomendasikan)
1. Buka aplikasi **MetaTrader 5** Anda.
2. Di menu atas, klik **File** &rarr; **Open Data Folder** (atau **Berkas** &rarr; **Buka Folder Data**).
3. Salin (copy) folder **`MQL5`** yang ada di paket ini.
4. Tempel (paste) langsung ke dalam jendela Data Folder yang terbuka. Jika muncul konfirmasi gabungkan/replace, pilih **Yes / Merge**.
5. *Selesai! Seluruh file `.ex5`, `.onnx`, dan `.set` langsung masuk ke lokasinya masing-masing.*

### Metode 2: Cara Manual (Copy Satu per Satu)
Jika Anda lebih suka menyalin file secara mandiri:
- Salin `PICA_Neural_Gold_M1_MT5.ex5` ke: `<Data Folder MT5>/MQL5/Experts/`
- Salin `PICA_Neural_Gold_M1.onnx` ke: `<Data Folder MT5>/MQL5/Files/`
- Salin semua file `.set` ke: `<Data Folder MT5>/MQL5/Presets/`

---

## 3. Cara Mengaktifkan EA pada Chart

1. Di MetaTrader 5, tekan **Ctrl + N** untuk memunculkan panel **Navigator**.
2. Klik kanan pada bagian **Expert Advisors** &rarr; klik **Refresh** (atau restart MT5).
3. Pastikan tombol **Algo Trading** di toolbar atas MT5 dalam posisi aktif (berwarna **HIJAU**).
4. Buka chart Emas: **`XAUUSD`** (atau `XAUUSD.s` / `GOLD`).
5. Set timeframe chart ke **`M1`** (1-Menit).
6. Tarik EA **`PICA_Neural_Gold_M1_MT5`** dari panel Navigator ke atas chart.
7. Pada tab **Common**:
   - Beri centang pada **`Allow Algo Trading`** (Izinkan Algoritma Trading).
8. Pada tab **Inputs**:
   - Klik tombol **Load**, lalu pilih salah satu preset dari folder `Presets` (misalnya: `02_PICA_M1_Balanced_Recommended.set`).
   - Pastikan parameter `InpModelFile` tertulis `PICA_Neural_Gold_M1.onnx`.
9. Klik **OK**.
10. Periksa tab **Experts** di bagian bawah layar MT5. Jika sukses, akan muncul pesan:
    ```text
    PICA Neural Gold initialized. Symbol=XAUUSD timeframe=PERIOD_M1 model=PICA_Neural_Gold_M1.onnx
    ```

---

## 4. Karakteristik & Pilihan Preset

| File Preset | Gaya Trading | Estimasi Sinyal | Win Rate | Expectancy | Rekomendasi Akun |
| :--- | :--- | :---: | :---: | :---: | :--- |
| **`01 Aggressive`** | High Frequency Scalper | ~75 trade/hari | 50.78% | +0.117R | Akun rebate / scalper aktif |
| **`02 Balanced`** *(Default)* | Seimbang & Konsisten | ~16 trade/hari | **52.43%** | **+0.153R** | **Semua jenis akun (Paling Stabil)** |
| **`03 Conservative`** | Hati-hati (Score $\ge 40\%$) | ~13 trade/hari | 52.35% | +0.152R | Akun dengan modal konservatif |
| **`04 Sniper`** | Sangat Selektif | ~3 trade/hari | **53.33%** | **+0.173R** | Khusus setup probabilitas puncak |

---

## 5. Tips Trading & Spesifikasi Akun

- **Timeframe Wajib**: **M1** (1-Menit). Jangan pasang di M5 atau H1.
- **Tipe Akun Terbaik**: ECN, Raw Spread, atau Pro (spread emas $\le 30$ point).
- **Proteksi Spread Otomatis**: Parameter `InpMaxSpreadPrice = 0.50` bertindak sebagai *auto-guard*. Jika spread pasar melebar di atas 50 sen (misal saat pergantian hari/rollover atau news NFP/FOMC), EA otomatis berhenti membuka posisi baru demi melindungi modal.
- **Manajemen Risiko**: Nilai risiko bawaan adalah `0.05%` per trade dengan stop loss otomatis berpatokan pada volatilitas ATR pasar.
